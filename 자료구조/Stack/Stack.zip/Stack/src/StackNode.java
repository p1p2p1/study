
public class StackNode {
	int data;
	StackNode link;
}
