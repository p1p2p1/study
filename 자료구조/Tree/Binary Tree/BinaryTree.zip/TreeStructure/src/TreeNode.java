
public class TreeNode {
	char data;
	TreeNode left;
	TreeNode right;
}
